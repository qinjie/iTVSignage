<?php
return [
    'application' => '/api',
];
