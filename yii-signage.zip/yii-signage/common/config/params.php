<?php
return [
    'adminEmail' => 'eceiot.np@gmail.com',
    'supportEmail' => 'eceiot.np@gmail.com',
    'user.passwordResetTokenExpire' => 3600,
];
