<?php
return [
    'name' => 'Yii Signage',
    'timeZone' => 'Asia/Singapore',
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'charset' => 'utf8',
            // ## Development
            'dsn' => 'mysql:host=127.0.0.1;dbname=yii-signage',
            'username' => '',
            'password' => '',
            // ## Production
//            'dsn' => 'mysql:host=iot-centre-rds.crqhd2o1amcg.ap-southeast-1.rds.amazonaws.com;dbname=yii-signage',
//            'username' => 'root',
//            'password' => 'Soe7014Ece',
        ],
        'mailer' => [
            'class' => 'yii\swiftmailer\Mailer',
            'viewPath' => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'image' => [
            'class' => 'yii\image\ImageDriver',
            'driver' => 'GD',  //GD or Imagick
        ],
    ],
];
